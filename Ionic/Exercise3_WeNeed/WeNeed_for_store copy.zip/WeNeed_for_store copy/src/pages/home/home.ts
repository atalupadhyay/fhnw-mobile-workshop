

import { Component, ViewChild } from '@angular/core';
import { NavController, Content } from 'ionic-angular';
import { Keyboard } from '@ionic-native/keyboard';


import { FirebaseServiceProvider } from './../../providers/firebase-service/firebase-service';
import { Observable } from 'rxjs/Observable';
import { ItemDetailsPage } from './../item-details/item-details';
import { LoadingController } from 'ionic-angular/components/loading/loading-controller';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
})
export class HomePage {
  @ViewChild(Content) content: Content;
  

  shoppingItems: Observable<any[]>;
  newItem:any = '';

  constructor(public navCtrl: NavController, public firebaseService: FirebaseServiceProvider, private keyboard: Keyboard, public loadingCtrl: LoadingController) {

    this.shoppingItems = this.firebaseService.getShoppingItems();
    console.log(" PRINTING SHOPING ITEMS" + this.shoppingItems);
    console.log(this.shoppingItems + " ---");
    this.keyboard.show();

  }

  addItem(){
    if(this.newItem.length === 0 || !this.newItem.trim()){
      console.log("empty");
    }else{
      console.log("adding something");
      this.firebaseService.addItem(this.newItem).then(()=>{
        this.newItem = "";
        this.keyboard.close();
        this.content.scrollToBottom();
      });
    }
  }

  removeItem(id){
    console.log("my id is: " + id);
    this.firebaseService.deleteItem(id);
   }

   doneItem(key, status){
      this.firebaseService.doneItem(key, status);
   }

   itemTapped(event, item) {
    this.navCtrl.push(ItemDetailsPage, {
      itemA: item
    });
  }

  onScroll(event){
    this.keyboard.close();
    console.log("scrolling!!!");
  }


}

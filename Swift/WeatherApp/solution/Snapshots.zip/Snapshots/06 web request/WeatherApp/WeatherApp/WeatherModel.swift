//
//  WeatherModel.swift
//  WeatherApp
//
//  Created by Oliver Gepp on 27.02.18.
//  Copyright © 2018 Team. All rights reserved.
//

import Foundation

class WeatherModel{
    
    let apiKey = "TODO"
    let long = "7.44744"
    let lat = "46.94809"
    let endpoint = "https://api.openweathermap.org/data/2.5/forecast/daily?lat={LAT}&lon={LON}&lang=de&units=metric&cnt=7&APPID={KEY}"
    
    func loadWeather(completionHandler: @escaping ([String: AnyObject]?, Error?) -> Void){
        
        let urlString = endpoint
            .replacingOccurrences(of: "{LAT}", with: lat)
            .replacingOccurrences(of: "{LON}", with: long)
            .replacingOccurrences(of: "{KEY}", with: apiKey)
        
        guard let url = URL(string: urlString) else {
            print("Error: cannot create URL")
            let error = BackendError.urlError(reason: "Could not construct URL")
            completionHandler(nil, error)
            return
        }
        let urlRequest = URLRequest(url: url)
        
        let session = URLSession.shared
        let task = session.dataTask(with: urlRequest, completionHandler: {
            (data, response, error) in

            guard error == nil else {
                completionHandler(nil, error!)
                return
            }
            
            guard let responseData = data else {
                print("Error: did not receive data")
                let error = BackendError.objectSerialization(reason: "No data in response")
                completionHandler(nil, error)
                return
            }
            
            do {
                let weatherDic = try JSONSerialization.jsonObject(
                    with: responseData,
                    options: .mutableContainers) as? [String: AnyObject]
                completionHandler(weatherDic, nil)
            } catch {
                print("error trying to convert ")
                print(error)
                completionHandler(nil, error)
            }
        })
        task.resume()
    }
}


enum BackendError: Error {
    case urlError(reason: String)
    case objectSerialization(reason: String)
}

//
//  ForecastCell.swift
//  WeatherApp
//
//  Created by Oliver Gepp on 03.03.18.
//  Copyright © 2018 Team. All rights reserved.
//

import UIKit

class ForecastCell: UITableViewCell {

    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }


}

//
//  WeatherItem.swift
//  WeatherApp
//
//  Created by Oliver Gepp on 12.03.18.
//  Copyright © 2018 Team. All rights reserved.
//

import Foundation

struct WeatherItem{
    
    var city: String
    var date: Date
    var min: Double
    var max: Double
    var description: String 
}

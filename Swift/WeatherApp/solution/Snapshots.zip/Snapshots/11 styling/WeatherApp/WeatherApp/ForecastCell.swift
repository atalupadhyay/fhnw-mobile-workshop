//
//  ForecastCell.swift
//  WeatherApp
//
//  Created by Oliver Gepp on 03.03.18.
//  Copyright © 2018 Team. All rights reserved.
//

import UIKit

class ForecastCell: UITableViewCell {

    
    @IBOutlet weak var weekdayLabel: UILabel!
    @IBOutlet weak var minTempLabel: UILabel!
    @IBOutlet weak var maxTempLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }


}

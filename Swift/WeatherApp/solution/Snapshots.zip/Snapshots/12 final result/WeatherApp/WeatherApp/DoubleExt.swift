//
//  DoubleExt.swift
//  WeatherApp
//
//  Created by Oliver Gepp on 19.03.18.
//  Copyright © 2018 Team. All rights reserved.
//

import Foundation

extension Double{
    
    func rounded(places: Int)->Double{
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
}

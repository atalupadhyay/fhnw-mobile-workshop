//
//  ViewController.swift
//  WeatherApp
//
//  Created by Oliver Gepp on 26.02.18.
//  Copyright © 2018 Team. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var daytTimeImageView: UIImageView!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var conditionLabel: UILabel!
    @IBOutlet weak var tempLabel: UILabel!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setBackgroundImage()
        resetLabels()
    }

    fileprivate func setBackgroundImage() {
        let hour = Calendar.current.component(.hour, from: Date())
        
        switch hour {
        case 0...6:
            daytTimeImageView.image = UIImage(named: "Blood")
        case 7...19:
            daytTimeImageView.image = UIImage(named: "Sun")
        case 19...22:
            daytTimeImageView.image = UIImage(named: "Moon")
        default:
            daytTimeImageView.image = UIImage(named: "Blood")
        }
    }
    
    fileprivate func resetLabels() {
        cityLabel.text = "?"
        conditionLabel.text = "?"
        tempLabel.text = "?"
    }
    
}


//
//  ViewController.swift
//  WeatherApp
//
//  Created by Oliver Gepp on 26.02.18.
//  Copyright © 2018 Team. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var daytTimeImageView: UIImageView!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var conditionLabel: UILabel!
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    
    
    private let weatherModel = WeatherModel()
    private var weatherItems = [WeatherItem]()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setBackgroundImage()
        resetLabels()
        tableView.dataSource = self
        
        weatherModel.loadWeather { (weatherItems: [WeatherItem]?, error: Error?) in
            
            DispatchQueue.main.async {
                
                guard let items = weatherItems else{return}
                
                if let item = items.first{
                    self.conditionLabel.text = item.description
                    self.tempLabel.text = "\(item.max) °C"
                    self.cityLabel.text = item.city
                }
                
                self.weatherItems.removeAll()
                self.weatherItems.append(contentsOf: items)
                self.tableView.reloadData()
            }
        }
    }

    fileprivate func setBackgroundImage() {
        let hour = Calendar.current.component(.hour, from: Date())
        
        switch hour {
        case 0...6:
            daytTimeImageView.image = UIImage(named: "Blood")
        case 7...19:
            daytTimeImageView.image = UIImage(named: "Sun")
        case 19...22:
            daytTimeImageView.image = UIImage(named: "Moon")
        default:
            daytTimeImageView.image = UIImage(named: "Blood")
        }
    }
    
    fileprivate func resetLabels() {
        cityLabel.text = "?"
        conditionLabel.text = "?"
        tempLabel.text = "?"
    }
    
}

extension ViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        return tableView.dequeueReusableCell(withIdentifier: "ForecastCell", for: indexPath)
    }
    
}


//
//  WeatherModel.swift
//  WeatherApp
//
//  Created by Oliver Gepp on 27.02.18.
//  Copyright © 2018 Team. All rights reserved.
//

import Foundation

class WeatherModel{
    
    let apiKey = "3f32ae699559cc963085bac1b8d45a3d"
    let long = "7.44744"
    let lat = "46.94809"
    let endpoint = "https://api.openweathermap.org/data/2.5/forecast/daily?lat={LAT}&lon={LON}&lang=de&units=metric&cnt=7&APPID={KEY}"
    
    func loadWeather(completionHandler: @escaping ([WeatherItem]?, Error?) -> Void){
        
        let urlString = endpoint
            .replacingOccurrences(of: "{LAT}", with: lat)
            .replacingOccurrences(of: "{LON}", with: long)
            .replacingOccurrences(of: "{KEY}", with: apiKey)
        
        guard let url = URL(string: urlString) else {
            print("Error: cannot create URL")
            let error = BackendError.urlError(reason: "Could not construct URL")
            completionHandler(nil, error)
            return
        }
        let urlRequest = URLRequest(url: url)
        
        let session = URLSession.shared
        let task = session.dataTask(with: urlRequest, completionHandler: {
            (data, response, error) in

            guard error == nil else {
                completionHandler(nil, error!)
                return
            }
            
            guard let responseData = data else {
                print("Error: did not receive data")
                let error = BackendError.objectSerialization(reason: "No data in response")
                completionHandler(nil, error)
                return
            }
            
            do {
                if let weatherDic = try JSONSerialization.jsonObject(
                    with: responseData,
                    options: .mutableContainers) as? [String: AnyObject]{
                        completionHandler(self.parseWeatherDictionary(weatherDic: weatherDic), nil)
                }
                else{
                    completionHandler(nil, nil)
                }
            } catch {
                print("error trying to convert ")
                print(error)
                completionHandler(nil, error)
            }
        })
        task.resume()
    }

    private func parseWeatherDictionary(weatherDic: [String: AnyObject])->[WeatherItem]{
        
        var result = [WeatherItem]()
        var cityName : String?
        
        if let city = weatherDic["city"] {
            if let city = city["name"] as? String{
                cityName = city
            }
        }
        
        if let listArray = weatherDic["list"] as? [AnyObject]{
            
            for case let item as [String: AnyObject] in listArray {
                
                var weatherDescription: String?
                var maxTemp: Double?
                var minTemp: Double?
                var date: Date?
                
                if let weatherArray = item["weather"] as? [AnyObject]{
                    if let fristWeatherItem =  weatherArray.first as? [String: AnyObject]{
                        if let description = fristWeatherItem["description"] as? String{
                            weatherDescription = description
                        }
                    }
                }
                
                if let interval = item["dt"] as? Double{
                    date = Date(timeIntervalSinceReferenceDate: interval)
                }
                
                if let tempArray = item["temp"] as? [String: AnyObject]{
                    if let temp = tempArray["max"] as? Double{
                        maxTemp = temp
                    }
                    
                    if let temp = tempArray["min"] as? Double{
                        minTemp = temp
                    }
                }
                
                guard let finalCityName = cityName else {continue}
                guard let finalDate = date else {continue}
                guard let finalMinTemp = minTemp else {continue}
                guard let finalMaxTemp = maxTemp else {continue}
                guard let finalDescription = weatherDescription else {continue}
                
                let weatherItem = WeatherItem(city: finalCityName, date: finalDate, min: finalMinTemp, max: finalMaxTemp, description: finalDescription)
                result.append(weatherItem)
            }
        }
        return result
    }
}




enum BackendError: Error {
    case urlError(reason: String)
    case objectSerialization(reason: String)
}

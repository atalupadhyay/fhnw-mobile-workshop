//
//  Item.swift
//  weneed
//
//  Created by Oliver Gepp on 02.04.18.
//  Copyright © 2018 FHNW. All rights reserved.
//

import Foundation
import Firebase

class Item{
    
    var id: String?
    var name: String = ""
    var isDone = false
    
    init(name: String){
        self.name = name
    }
    
    func asDictionary()->[String:AnyObject]{
        return ["name": name as AnyObject,
                "isDone": isDone ? 1 as AnyObject: 0 as AnyObject]
    }
    
    static func parse(_ dataItem: DataSnapshot)->Item?{
        if let dic = dataItem.value as? Dictionary<String, AnyObject>{
            let item = Item(name:  dic["name"] as! String)
            item.isDone = dic["isDone"] as! Bool
            item.id = dataItem.key
            return item
        }
        return nil
    }
}

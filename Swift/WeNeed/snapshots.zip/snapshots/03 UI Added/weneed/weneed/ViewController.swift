//
//  ViewController.swift
//  weneed
//
//  Created by Oliver Gepp on 31.03.18.
//  Copyright © 2018 FHNW. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    private let model = ItemModel()
    
    @IBOutlet weak var tableView: UITableView!
    @IBAction func addItemTapped(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }
    
}


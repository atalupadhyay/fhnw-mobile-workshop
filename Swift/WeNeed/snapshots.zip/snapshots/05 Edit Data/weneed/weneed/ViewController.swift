//
//  ViewController.swift
//  weneed
//
//  Created by Oliver Gepp on 31.03.18.
//  Copyright © 2018 FHNW. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    private let model = ItemModel()
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBAction func addItemTapped(_ sender: Any) {
        requestNewItem()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        model.delegate = self
    }
    
    func refreshUI(){
        tableView.reloadData()
    }
    
    func requestNewItem(){
        
        let alert = UIAlertController(title: "Add new item", message: nil, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addTextField(configurationHandler: { textField in
            textField.placeholder = "Item name"
        })
        alert.addAction(UIAlertAction(title: "Add", style: .default, handler: { action in
            if let name = alert.textFields?.first?.text {
                if name.count > 0{
                    self.model.addItem(name: name)
                }
            }
        }))
        self.present(alert, animated: true)
    }
    
    func editItem(item: Item){
        let alert = UIAlertController(title: "Edit item", message: nil, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addTextField(configurationHandler: { textField in
            textField.placeholder = "Item name"
            textField.text = item.name
        })
        alert.addAction(UIAlertAction(title: "Save", style: .default, handler: { action in
            if let name = alert.textFields?.first?.text {
                if name.count > 0{
                    self.model.updateItem(item: item, name: name, isDone: item.isDone)
                }
            }
        }))
        self.present(alert, animated: true)
    }
}

extension ViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: indexPath)
        let item = model.items[indexPath.row]
        cell.textLabel?.text = item.name
        cell.accessoryType = item.isDone ? .checkmark : .none
        return cell
    }
}

extension ViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       let item = self.model.items[indexPath.row]
        model.updateItem(item: item, name: item.name, isDone: !item.isDone)
    }
    
    func tableView(_ tableView: UITableView,
                   leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let editAction = UIContextualAction(style: .normal, title:  "Edit", handler: { (ac:UIContextualAction, view:UIView, success:(Bool) -> Void) in
            let item = self.model.items[indexPath.row]
            self.editItem(item: item)
        })
        editAction.backgroundColor = .blue
        return UISwipeActionsConfiguration(actions: [editAction])
    }
    
    func tableView(_ tableView: UITableView,
                   trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let deleteAction = UIContextualAction(style: .normal, title:  "Delete", handler: { (ac:UIContextualAction, view:UIView, success:(Bool) -> Void) in
            if let itemID = self.model.items[indexPath.row].id{
                self.model.deleteItem(id: itemID)
            }
        })
        deleteAction.backgroundColor = .red
        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
    
}


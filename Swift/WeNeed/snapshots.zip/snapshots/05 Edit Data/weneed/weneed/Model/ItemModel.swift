//
//  ItemModel.swift
//  weneed
//
//  Created by Oliver Gepp on 02.04.18.
//  Copyright © 2018 FHNW. All rights reserved.
//

import Foundation
import Firebase

class ItemModel{
    
    private var ref: DatabaseReference!
    var items = [Item]()
    var delegate: ViewController?
    
    init() {
        configureDatabase()
        addListeners()
    }
    
    deinit {
        ref.removeAllObservers()
    }
    
    private func configureDatabase() {
        FirebaseApp.configure()
        ref = Database.database().reference()
    }
    
    private func addListeners(){

        ref.observe(.value) { (snapshot) in
             self.updateItems(snapshot: snapshot)
        }
    }
    
    
    private func updateItems(snapshot: DataSnapshot){
        items.removeAll()
        if let dataSnapshots = snapshot.children.allObjects as? [DataSnapshot]{
            for dataSnapshot in dataSnapshots{
                if let snaps = dataSnapshot.children.allObjects as? [DataSnapshot]{
                    for snap in snaps {
                        if let item = Item.parse(snap){
                            self.items.append(item)
                        }
                    }
                }
            }
        }
        delegate?.refreshUI()
    }
    

    
    func addItem(name: String){
        let item = Item.init(name: name)
        self.ref.child("items").childByAutoId().setValue(item.asDictionary())
    }
    
    func deleteItem(id: String){
        self.ref.child("items").child(id).removeValue()
    }
    
    func markItemAsDone(item:Item){
        item.isDone = false
        self.ref.child("items").child(item.id!).updateChildValues(item.asDictionary())
    }
    
    func updateItem(item: Item, name: String, isDone: Bool){
        item.name = name
        item.isDone =  isDone
        self.ref.child("items").child(item.id!).updateChildValues(item.asDictionary())
    }
 
}

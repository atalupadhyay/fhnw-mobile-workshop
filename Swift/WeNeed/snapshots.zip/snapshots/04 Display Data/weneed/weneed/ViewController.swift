//
//  ViewController.swift
//  weneed
//
//  Created by Oliver Gepp on 31.03.18.
//  Copyright © 2018 FHNW. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    private let model = ItemModel()
    
    @IBOutlet weak var tableView: UITableView!
    @IBAction func addItemTapped(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        model.delegate = self
    }
    
    func refreshUI(){
        tableView.reloadData()
    }
}

extension ViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: indexPath)
        cell.textLabel?.text = model.items[indexPath.row].name
        return cell
    }
}

extension ViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("row \(indexPath) selected")
    }
}

